package com.groupf.hackathon.response;

import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class StationList {

	private List<Station> Stations;
	
	/*
	 * public StationList() {
	 * 
	 * List<Station> Stations = new ArrayList<>(); }
	 */
	
	
}
