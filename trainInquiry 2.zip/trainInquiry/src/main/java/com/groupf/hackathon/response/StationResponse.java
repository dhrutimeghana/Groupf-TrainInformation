package com.groupf.hackathon.response;

import lombok.*;

@Getter
@Setter
@ToString(includeFieldNames=true)
public class StationResponse {

	private long stationId;
	
	private String stationName;
	
	private String arrivalTime;
	
	private String departureTime;
	
	private long trainId;
	
}
