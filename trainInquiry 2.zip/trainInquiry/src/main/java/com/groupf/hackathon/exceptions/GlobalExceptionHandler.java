package com.groupf.hackathon.exceptions;

import org.springframework.http.HttpStatus;


import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.groupf.hackathon.entity.Train;
import com.groupf.hackathon.exceptions.ExceptionResponse;
import com.groupf.hackathon.exceptions.TrainNotFoundException;
import com.groupf.hackathon.response.StationResponseBody;
import com.groupf.hackathon.response.StationResponseStatus;
import com.groupf.hackathon.response.StationsInquiryResponse;
import com.groupf.hackathon.response.TrainInquiryResponse;
import com.groupf.hackathon.response.TrainResponseBody;
import com.groupf.hackathon.response.TrainResponseStatus;




@RestControllerAdvice("com.groupf.hackathon.controller")
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler	 {
	
	
	@Autowired 
	StationsInquiryResponse stationsInquiryResponse;
	
	@Autowired
	StationResponseBody stationResponseBody;
	
	@Autowired
	StationResponseStatus stationResponseStatus;
	
	@Autowired
	Train train;
	
	@Autowired
	TrainResponseBody trainResponseBody;
	
	@Autowired
	TrainResponseStatus trainResponseStatus;
	
	@Autowired
	TrainInquiryResponse trainInquiryResponse;
	

	@ExceptionHandler(Exception.class)
	public ResponseEntity<TrainInquiryResponse> genericException(Exception ex) {
		
		
		ExceptionResponse exceptionResponse = new ExceptionResponse( HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(),
				"Internal Server Error");
				
				//TrainInquiryResponse response = new TrainInquiryResponse();
				
				trainInquiryResponse.getTrainResponseBody().setTrainId(0);
				trainInquiryResponse.getTrainResponseBody().setTrainName(null);
				trainInquiryResponse.getTrainResponseBody().setStations(null);
				trainInquiryResponse.getTrainResponseStatus().setHttpStatus(HttpStatus.NOT_FOUND);
				trainInquiryResponse.getTrainResponseStatus().setMessage(ex.getMessage());
				trainInquiryResponse.getTrainResponseStatus().setSource("/train/api/getByTrainId/");
				
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(trainInquiryResponse);
				
				
	}

}
