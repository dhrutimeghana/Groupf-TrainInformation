package com.groupf.hackathon.exceptions;

public class TrainNotFoundException extends RuntimeException{
	
	private String message;
	
	public TrainNotFoundException(String message) {
		
		super(message);
		this.message = message;
	}

}
