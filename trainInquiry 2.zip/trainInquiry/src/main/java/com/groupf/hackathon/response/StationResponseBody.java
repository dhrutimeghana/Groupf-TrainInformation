package com.groupf.hackathon.response;

import java.util.List;

import com.groupf.hackathon.response.Station;

import lombok.*;
import org.springframework.stereotype.Component;

@Getter
@Setter

@Component
public class StationResponseBody {

	/*
	 * private long id;
	 * 
	 * private long stationId;
	 * 
	 * private String stationName;
	 * 
	 * private String arrivalTime;
	 * 
	 * private String departureTime;
	 * 
	 * private long trainId;
	 */	
	
	private List<Station> Stations;
	/*
	 * public StationResponse(Station station) { this.id = station.getId();
	 * this.stationId = station.getStationId(); this.stationName =
	 * station.getStationName(); this.arrivalTime = station.getArrivalTime();
	 * this.departureTime = station.getDepartureTime(); this.trainId =
	 * station.getTrainId(); }
	 */
}
