package com.groupf.hackathon.request;

import lombok.*;

@Getter
@Setter
public class CreateTrainRequest {

	private long trainId;
	private String trainName;

}
