package com.groupf.hackathon.response;

import java.util.List;

import com.groupf.hackathon.entity.Train;

import lombok.*;

@Getter
@Setter
@ToString(includeFieldNames=true)
public class TrainResponse {

	private String trainName;
	
	private long trainId;
	
	private StationsInquiryResponse stationsInquiryResonse;
	
	/*
	 * public TrainResponse(Train train) { this.trainName = train.getTrainName();
	 * this.trainId = train.getTrainId(); }
	 */

}
