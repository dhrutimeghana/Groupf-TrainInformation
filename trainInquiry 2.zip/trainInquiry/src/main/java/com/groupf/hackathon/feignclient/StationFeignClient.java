package com.groupf.hackathon.feignclient;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.groupf.hackathon.response.StationResponse;


/* @FeignClient(value="station-feign-client",url="http://localhost:8082/api/station/") */
@FeignClient(value="station-service-api", path="/station/api")
public interface StationFeignClient {
	
	@GetMapping("/getByTrainId/{trainId}")
	//public StationResponse getByTrainId(@PathVariable long trainId);
	public List<StationResponse> getByTrainId(@PathVariable long trainId);
	
}
