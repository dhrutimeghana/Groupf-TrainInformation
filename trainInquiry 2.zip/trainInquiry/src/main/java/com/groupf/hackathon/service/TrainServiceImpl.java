package com.groupf.hackathon.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.groupf.hackathon.entity.Train;
import com.groupf.hackathon.repository.TrainRepository;
import com.groupf.hackathon.exceptions.*;

@Component
@Service
public class TrainServiceImpl implements TrainService {

	@Autowired
	TrainRepository trainRepository;
	
	
	@Override
	public Train getById(long Id) {
		//try {
			Train train = trainRepository.findById(Id).get();
			return train;
	//	}catch(Exception ex) {
			
	//		throw new TrainNotFoundException("Train not found for Train Id " + Id + " due to error :" + ex.getMessage());
	//	}
	
	}

}
