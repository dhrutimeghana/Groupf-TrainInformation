package com.groupf.hackathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
//import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.cloud.netflix.eureka.*;


@SpringBootApplication
//@ComponentScan({"com.groupf.hackathon.controller", "com.groupf.hackathon.service", "com.groupf.hackathon.config", "com.groupf.hackathon.exceptions", "com.groupf.hackathon.response"})
@EntityScan("com.groupf.hackathon.entity")
@EnableJpaRepositories("com.groupf.hackathon.repository")

public class TrainInquiryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainInquiryApplication.class, args);
	}

}
