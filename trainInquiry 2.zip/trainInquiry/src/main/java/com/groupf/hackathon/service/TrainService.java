package com.groupf.hackathon.service;

import org.springframework.stereotype.Service;

import com.groupf.hackathon.entity.Train;

@Service
public interface TrainService {
	
	Train getById(long Id);

}
