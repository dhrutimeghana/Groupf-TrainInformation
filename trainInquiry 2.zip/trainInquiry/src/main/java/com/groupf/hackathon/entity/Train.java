package com.groupf.hackathon.entity;

import lombok.*;

import jakarta.persistence.*;
import org.springframework.stereotype.Component;

@Getter
@Setter
@ToString(includeFieldNames=true)
@Entity
@Table(name = "train")
@Component
public class Train {

	@Id
	@Column(name = "train_id")
	private long trainId;

	@Column(name = "train_name")
	private String trainName;
	
}
