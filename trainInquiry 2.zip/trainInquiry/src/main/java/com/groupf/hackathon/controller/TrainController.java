package com.groupf.hackathon.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.modelmapper.ModelMapper;

import com.groupf.hackathon.entity.Train;
//import com.groupf.hackathon.feignclient.StationFeignClient;
import com.groupf.hackathon.request.CreateTrainRequest;
import com.groupf.hackathon.response.StationList;
import com.groupf.hackathon.response.StationResponse;
import com.groupf.hackathon.response.StationResponseBody;
import com.groupf.hackathon.response.StationResponseStatus;
import com.groupf.hackathon.response.StationsInquiryResponse;
import com.groupf.hackathon.response.TrainInquiryResponse;
import com.groupf.hackathon.response.Station;
import com.groupf.hackathon.response.TrainResponse;
import com.groupf.hackathon.response.TrainResponseBody;
import com.groupf.hackathon.response.TrainResponseStatus;
import com.groupf.hackathon.service.TrainService;
import com.groupf.hackathon.service.TrainServiceImpl;

@RestController
@RequestMapping("/")
public class TrainController {

	Logger logger = LoggerFactory.getLogger(TrainController.class);
	
		
	@Autowired
	LoadBalancerClient loadbal;
	
	@Autowired
	TrainServiceImpl trainService;
	
	
	@Autowired
	ModelMapper modelMapper;
	
	@Autowired 
	RestTemplate restTemplate;
	
	@Autowired 
	StationsInquiryResponse stationsInquiryResponse;
	
	@Autowired
	StationResponseBody stationResponseBody;
	
	@Autowired
	StationResponseStatus stationResponseStatus;
	
	@Autowired
	Train train;
	
	@Autowired
	TrainResponseBody trainResponseBody;
	
	@Autowired
	TrainResponseStatus trainResponseStatus;
	
	@Autowired
	TrainInquiryResponse trainInquiryResponse;
	
	
	
	@Value("${station.service.url}")
	private String stationUri;
	
	
	@GetMapping("/getByTrainId/{trainId}")
	
	public ResponseEntity<TrainInquiryResponse> getByTrainId(@PathVariable long trainId) {


		//Train train = trainService.getById(trainId);
		
		train = trainService.getById(trainId);
		
		//TrainResponse trainResponse  = modelMapper.map(train, TrainResponse.class);
		
		if (train == null) {
			
			trainResponseBody = null;
			trainResponseStatus.setHttpStatus(HttpStatus.NOT_FOUND);
			trainResponseStatus.setMessage("Train not found for TrainId: " + trainId);
			trainResponseStatus.setSource("/getByTrainId/" + trainId);
			
		
			
						
		} else {
		
			//	String finalURI = stationUri + trainId;
			
			  ServiceInstance service = loadbal.choose("STATION-SERVICE-API"); 
			  String uri = service.getUri().toString(); 
			  String finalUri = uri + "/station/api/getByTrainId/" + trainId;
			 
		
		
				trainResponseBody = modelMapper.map(train, TrainResponseBody.class);
				stationsInquiryResponse = restTemplate.getForObject(finalUri, StationsInquiryResponse.class);
				trainResponseBody.setStations(stationsInquiryResponse.getBody().getStations());
				
				trainResponseStatus.setHttpStatus(HttpStatus.OK);
				trainResponseStatus.setMessage("Train details found");
				trainResponseStatus.setSource("/getByTrainId/" + trainId);
			
		}
				
		trainInquiryResponse.setTrainResponseBody(trainResponseBody);
		trainInquiryResponse.setTrainResponseStatus(trainResponseStatus);
		return ResponseEntity.status(HttpStatus.OK).body(trainInquiryResponse);
	}
}
