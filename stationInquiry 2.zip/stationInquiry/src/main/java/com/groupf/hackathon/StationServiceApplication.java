package com.groupf.hackathon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.groupf.hackathon.exceptions.GlobalExceptionHandler;

@SpringBootApplication
@ComponentScan({"com.groupf.hackathon.controller", "com.groupf.hackathon.service", "com.groupf.hackathon.exceptions", "com.groupf.hackathon.response"})
@EntityScan("com.groupf.hackathon.entity")
@EnableJpaRepositories("com.groupf.hackathon.repository")
@Import(GlobalExceptionHandler.class)

public class StationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StationServiceApplication.class, args);
	}

}
