package com.groupf.hackathon.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.groupf.hackathon.entity.Station;
import com.groupf.hackathon.exceptions.StationNotFoundException;
import com.groupf.hackathon.repository.StationRepository;
import com.groupf.hackathon.request.CreateStationRequest;
import com.groupf.hackathon.response.StationResponseBody;

@Service
public class StationServiceImpl implements StationService {
	Logger logger = LoggerFactory.getLogger(StationServiceImpl.class);
	
	@Autowired
	private StationRepository stationRepository;
	
	
	public List<Station> getByTrainId(long trainId) {
		
		logger.info("Inside StationService - getByTrainId " + trainId);
		
		
		return stationRepository.findByTrainId(trainId);
		
	}

}
