package com.groupf.hackathon.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.groupf.hackathon.entity.Station;
import com.groupf.hackathon.exceptions.*;
import com.groupf.hackathon.request.CreateStationRequest;
import com.groupf.hackathon.response.StationResponseBody;
import com.groupf.hackathon.response.StationResponseStatus;
import com.groupf.hackathon.response.StationsInquiryResponse;
import com.groupf.hackathon.service.StationServiceImpl;

@RestController
@RequestMapping("/getByTrainId")
public class StationController {

	Logger logger = LoggerFactory.getLogger(StationController.class);
	
	@Autowired
	StationServiceImpl stationService;
	
	@Autowired
	StationResponseBody stationsresp;
	
	@Autowired 
	StationResponseStatus respStatus;
	
	@Autowired
	StationsInquiryResponse stationsInquiryResponse;
	
	
	
	@GetMapping("/{trainId}")
	//public List<Station> getByTrainId(@PathVariable long trainId) {
	public ResponseEntity<StationsInquiryResponse> getByTrainId(@PathVariable long trainId) {
		
			List<Station> stationsList = stationService.getByTrainId(trainId);
			if (stationsList.isEmpty()) {
				
				respStatus.setHttpStatus(HttpStatus.NOT_FOUND);
				respStatus.setSource("/station/api/getByTrainId/" + trainId);
				
				//throw new StationNotFoundException("No stations found for Train Id: " + trainId);
			}else {
				
				respStatus.setHttpStatus(HttpStatus.FOUND);
				respStatus.setSource("/station/api/getByTrainId/" + trainId);
				
			}
			//return stationsList;
			
			stationsresp.setStations(stationsList);
			stationsInquiryResponse.setBody(stationsresp);
			stationsInquiryResponse.setStatus(respStatus);
			
			
			return ResponseEntity.status(HttpStatus.OK).body(stationsInquiryResponse);
		
	}
	

	
}
