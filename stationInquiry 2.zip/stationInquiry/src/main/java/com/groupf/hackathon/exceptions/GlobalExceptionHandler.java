package com.groupf.hackathon.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.groupf.hackathon.exceptions.ExceptionResponse;
import com.groupf.hackathon.exceptions.StationNotFoundException;

@RestControllerAdvice("com.groupf.hackathon.controller")
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler	 {
	
	
	@ExceptionHandler(com.groupf.hackathon.exceptions.StationNotFoundException.class)
	public ResponseEntity<ExceptionResponse> stationNotFoundException(StationNotFoundException stationNotfound) {
		
		
		ExceptionResponse exceptionResponse = new ExceptionResponse( HttpStatus.NOT_FOUND,stationNotfound.getMessage(),
				"Failed to retrieve Stations list from Station Table");
				return new ResponseEntity<ExceptionResponse>(exceptionResponse, new HttpHeaders(),HttpStatus.NOT_FOUND);
	}
		
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ExceptionResponse> genericException(Exception ex) {
		
		
		ExceptionResponse exceptionResponse = new ExceptionResponse(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(),
				"Internal Server Error");
				return new ResponseEntity<ExceptionResponse>(exceptionResponse, new HttpHeaders(),HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
