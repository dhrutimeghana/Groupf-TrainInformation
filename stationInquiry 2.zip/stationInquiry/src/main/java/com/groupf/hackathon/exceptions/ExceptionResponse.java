package com.groupf.hackathon.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ExceptionResponse {
	private HttpStatus responseStatus;
	private Date timestamp = new Date();
	private String message;
	private String details;
	public ExceptionResponse(HttpStatus responseStatus, String message, String details) {
			super();
			this.responseStatus = responseStatus;
			this.message = message;
			this.details = details;
	}

}