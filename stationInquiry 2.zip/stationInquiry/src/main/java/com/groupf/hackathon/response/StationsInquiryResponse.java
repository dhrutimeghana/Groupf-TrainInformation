package com.groupf.hackathon.response;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Getter
@Setter
@ToString(includeFieldNames=true)
@Component
public class StationsInquiryResponse {
	
	StationResponseBody body;
	StationResponseStatus status;

}
