package com.groupf.hackathon.service;

import java.util.List;

import com.groupf.hackathon.entity.Station;


public interface StationService {
	List<Station> getByTrainId(long trainId);

}
