package com.groupf.hackathon.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.groupf.hackathon.entity.Station;

@Repository
public interface StationRepository extends JpaRepository<Station, Long> {
	
	List<Station> findByTrainId(long trainId);
}
