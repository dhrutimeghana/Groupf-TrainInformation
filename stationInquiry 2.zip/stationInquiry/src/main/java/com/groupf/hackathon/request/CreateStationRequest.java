package com.groupf.hackathon.request;

import lombok.*;

@Getter
@Setter
public class CreateStationRequest {

	private long stationId;
	
	private String stationName;
	
	private String arrivalTime;
	
	private String departureTime;
	
	private long trainId;
}
