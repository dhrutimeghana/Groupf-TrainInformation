package com.groupf.hackathon.entity;

import lombok.*;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Getter
@Setter
@Entity
@Table(name = "station")
public class Station {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long id;
	
	@Column(name = "station_id")
	private long stationId;

	@Column(name = "station_name")
	private String stationName;
	
	@Column(name = "arrival_time")
	private String arrivalTime;
	
	@Column(name = "departure_time")
	private String departureTime;
	
	@Column(name = "train_id")
	private long trainId;
}
