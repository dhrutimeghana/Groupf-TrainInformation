package com.groupf.hackathon.response;

import java.util.List;

import com.groupf.hackathon.entity.Station;

import lombok.*;
import org.springframework.stereotype.Component;

@Getter
@Setter

@Component
public class StationResponseBody {

	/*
	 * private long id;
	 * 
	 * private long stationId;
	 * 
	 * private String stationName;
	 * 
	 * private String arrivalTime;
	 * 
	 * private String departureTime;
	 * 
	 * private long trainId;
	 */	
	
	private List<Station> Stations;
	
}
