package com.traininfo.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
