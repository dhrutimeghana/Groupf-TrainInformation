package com.groupf.hackathon.TrainInquiryApp.controllers;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.groupf.hackathon.TrainInquiryApp.models.Message;
import com.groupf.hackathon.TrainInquiryApp.models.Train;
import com.groupf.hackathon.TrainInquiryApp.responses.StationResponseBody;
import com.groupf.hackathon.TrainInquiryApp.responses.StationResponseStatus;
import com.groupf.hackathon.TrainInquiryApp.responses.StationsInquiryResponse;
import com.groupf.hackathon.TrainInquiryApp.responses.TrainInquiryResponse;
import com.groupf.hackathon.TrainInquiryApp.responses.TrainResponseBody;
import com.groupf.hackathon.TrainInquiryApp.responses.TrainResponseStatus;

import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@Controller
@RequestMapping("/")
public class TrainInquiryController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@Autowired
	private LoadBalancerClient loadbal;
	
	@Autowired 
	StationsInquiryResponse stationsInquiryResponse;
	
	@Autowired
	StationResponseBody stationResponseBody;
	
	@Autowired
	StationResponseStatus stationResponseStatus;
	
	@Autowired
	Train train;
	
	@Autowired
	Message message;
	
	@Autowired
	TrainResponseBody trainResponseBody;
	
	@Autowired
	TrainResponseStatus trainResponseStatus;
	
	@Autowired
	TrainInquiryResponse trainInquiryResponse;
	
	@Autowired
	ModelMapper modelMapper;
	 
	@Value("${train.service.base-url}")
	String TrainUri;
	@RequestMapping("/")
	public ModelAndView showHomePage(ModelAndView modelandview) {
		
			modelandview.setViewName("TrainDetails");
			return modelandview;
	}
	

	@RequestMapping(path="/inquire", method=RequestMethod.GET)
	
	
	public ModelAndView inquireTrain(Train train, ModelAndView modelandview, String trainId) {
		
	
		
		
		
		  ServiceInstance service = loadbal.choose("TRAIN-SERVICE-API"); 
		  String uri = service.getUri().toString(); 
		  String finalUri = uri + "/train/api/getByTrainId/" + trainId;
		 
	//	String finalUri = TrainUri + trainId;
		System.out.println("--------From Train App URL is : " + finalUri);
		//train = restTemplate.getForObject(finalUri, Train.class);
		
		try {
			trainInquiryResponse = restTemplate.getForObject(finalUri,TrainInquiryResponse.class);
		}catch(Exception ex){
		//	
		//	System.out.println("--------: " + ex.getMessage());
			train.setTrainId( Long.parseLong(trainId));
			train.setTrainName("");
			train.setStations(null);
			message.setHttpStatus(HttpStatus.NOT_FOUND);
			message.setMessage("Train Number :" + trainId + " Details Not Found");
			String responsecode = message.getHttpStatus().toString();
			modelandview.setViewName("TrainDetails");
			modelandview.addObject("train", train);
			modelandview.addObject("message", message);
			modelandview.addObject("responsecode",responsecode);
			return modelandview;		
			
			
	
		}
		
		
		train = modelMapper.map(trainInquiryResponse.getTrainResponseBody(), Train.class);
		message = modelMapper.map(trainInquiryResponse.getTrainResponseStatus(), Message.class);
		String responsecode = message.getHttpStatus().toString();

		System.out.println("--------From Train App Stations are : " + train.getStations());
		modelandview.setViewName("TrainDetails");
		modelandview.addObject("train", train);
		modelandview.addObject("message", message);
		modelandview.addObject("responsecode",responsecode);
		return modelandview;		
		
	}

}
