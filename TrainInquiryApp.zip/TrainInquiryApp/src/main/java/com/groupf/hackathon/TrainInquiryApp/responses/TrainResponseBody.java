package com.groupf.hackathon.TrainInquiryApp.responses;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

import org.springframework.stereotype.Component;

@Getter
@Setter
@ToString(includeFieldNames=true)
@Component

public class TrainResponseBody {
	
	private long trainId;
	private String trainName;
	private List<Station> stations;

}
