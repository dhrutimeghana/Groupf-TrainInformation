package com.groupf.hackathon.TrainInquiryApp.models;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString(includeFieldNames=true)
@Component
public class Message {
	private HttpStatus httpStatus;
	private String Message;
	private String Source;
	

}
