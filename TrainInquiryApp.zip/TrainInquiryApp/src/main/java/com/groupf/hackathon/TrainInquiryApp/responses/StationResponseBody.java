package com.groupf.hackathon.TrainInquiryApp.responses;

import java.util.List;

import com.groupf.hackathon.TrainInquiryApp.responses.Station;

import lombok.*;
import org.springframework.stereotype.Component;

@Getter
@Setter

@Component
public class StationResponseBody {

		
	
	private List<Station> Stations;
	
}
