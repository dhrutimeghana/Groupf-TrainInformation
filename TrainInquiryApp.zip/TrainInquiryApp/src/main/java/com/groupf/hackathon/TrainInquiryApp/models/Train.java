package com.groupf.hackathon.TrainInquiryApp.models;

import org.springframework.stereotype.Component;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(includeFieldNames=true)
@Component
public class Train {

	private String trainName;
	
	private long trainId;
	
	private List<Station> stations;
	
}
