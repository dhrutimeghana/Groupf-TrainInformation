package com.groupf.hackathon.TrainInquiryApp.responses;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(includeFieldNames=true)
public class Station {

	private long id;
	
	private long stationId;
	
	private String stationName;
	
	private String arrivalTime;
	
	private String departureTime;
	
	private long trainId;
}
