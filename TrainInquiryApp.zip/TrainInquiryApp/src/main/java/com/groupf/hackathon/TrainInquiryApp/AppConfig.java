package com.groupf.hackathon.TrainInquiryApp;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.web.client.RestTemplate;

import javax.sql.DataSource;

@Configuration
public class AppConfig {
	
	@Bean
	ModelMapper getMapper() {
		
		return new ModelMapper();
	}
  
	@Bean
	RestTemplate getRestTemplate() {
		
		return new RestTemplate();
	}
}